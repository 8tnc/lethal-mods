# V1.0.0
 - Replace Large Axle drop sound with metal bar meme sound effect

# V1.1.0
 - Support for r2modman, special thanks to sunnobunno https://thunderstore.io/c/lethal-company/p/sunnobunno

# V1.1.1
 - Fixed plugin version metadata
 - Improved readme file