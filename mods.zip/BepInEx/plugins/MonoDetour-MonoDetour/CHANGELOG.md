# Changelog

MonoDetour's changelogs can be found in GitHub releases: <https://github.com/MonoDetour/MonoDetour/releases>
