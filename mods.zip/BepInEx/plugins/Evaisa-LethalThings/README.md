# LethalThings
**A content mod for Lethal Company that adds a ton of content!**  
*Features list at bottom of page!*  

## Credits:
- [Evaisa](https://evaisa.dev/) 
	- Making the mod and api and everything.
	- Hi I'm eba.  
- [Bobilka](https://www.artstation.com/bobilka)   
	- Models  
	- Ideas  
	- Textures  
	- Testing  
- Antlers  
	- Models  
	- Cookie model  
	- Testing  
- LocalHyena  
	- Models  
	- Textures  
- [Jek Korpen](https://twitter.com/Jek_Korpen)  
	- Nikki (Cookie) character design.  
- Regretevator (Roblox)
	- Gnarpy origin (I think)
- [horinhorin2006](https://twitter.com/horinhorin2006)
	- Art which was used as a reference for the gnarpy model.	
- [MrDrNose - EternityDev](https://mrdrnose.itch.io/)
	- The maxwell song, and the evil maxwell bones, originate from the game [Voices Of The Void](https://mrdrnose.itch.io/votv) (amazing game i recommend checking it out.)
- [Nolla Games](https://nollagames.com/)
	- Toimari / Hämis characters.
	
## Scrap items
- Plushy named Arson  
	- May set your house on fire if you displease her.  
![Arson](https://i.imgur.com/OnCGKcl.png)
  
- Plushy named arson (Dirty)  
	- Ew stinky  
![Arson](https://i.imgur.com/Buk3lQ2.png)
  
- Toimari plushy  
	- Noita reference  
![Toimari](https://i.imgur.com/STXtpHc.png)
  
- Hämis plushy  
	- Very soft.  
	- May nibble you a little.  
![Hämis](https://i.imgur.com/rM41HbK.png)
  
- Cookie Fumo 
	- Says strange things when you squeeze her.  
	- (Nikki) the character by Jek Korpen  
![Cookie](https://i.imgur.com/aMiji2H.png)
  
- Maxwell
	- Purrs loudly.  
	- Meows.  
	- Plays a silly little song.  
	- Does a silly little dance.  
![Maxwell](https://i.imgur.com/nccQTQy.png)  

- Glizzy  
	- Can be thrown at colleagues.  
![Glizzy](https://i.imgur.com/OQUi2hq.png)  

- Revolver  
	- Pew pew!!  
![Revolver](https://i.imgur.com/V4YnhFe.png)  

- Gremlin Energy Drink   
	- 100% lethal!!   
![GremlinEnergy](https://i.imgur.com/A0lzXY0.png)  

- Toy Hammer
	- Good for bonking unruly employees.  
	- We are not responsible for any fatalities related to this item.  
	- Clowns are known to love this one.  
![Hammer](https://i.imgur.com/UDtb5GC.png)

- Gnarpy Plush  
	- Some kind of alien critter   
![GremlinEnergy](https://i.imgur.com/t8Zd7uE.png)  
  
## Store items

- Rocket Launcher  
	- For if you want to go on the offense.  
	- Only has 4 shots.  
	- Highly fatal to team members.  
![RocketLauncher](https://i.imgur.com/lzDTH3E.png)
  
- Utility Belt  
	- Additional storage for scrap.  
	- +10 charisma.  
![Belt](https://i.imgur.com/Jlt0Hmi.png)  
  
- Remote Radar
	- Access the ship radar system remotely.  
	- Very limited battery life.   
	- May piss off anyone actively watching the radar terminal.    
![RemoteRadar](https://i.imgur.com/7cdQeNm.png)  
  
- Hacking Tool  
	- Unlock gates, disable turrets and mines, from up close.  
	- Requires basic math skills.  
![HackingTool](https://cdn.discordapp.com/attachments/511206402493251586/1180890040990171186/g-3dUIk1R.png) 

- Flare gun  
	- Attracts certain enemies.   
	- Flares are automatically pinged by employees.  
	- Ammo can be bought from the store.  
![Flaregun](https://i.imgur.com/8NTZyQ3.png) 

- Pinger  
	- Sends a location ping to your nearby colleagues.   
![Pinger](https://i.imgur.com/C6NxvEY.png) 

## Decor  
- Small/Large Rug  
	- Improve your living space!  
![Rugs](https://i.imgur.com/JXXXeoW.png)
   
- Fatalities Sign
	- A sign which reflects the efficacy of your crew.  
	- Automatically updates.  
![FatalitiesSign](https://cdn.discordapp.com/attachments/511206402493251586/1180888999951355985/sSk78gIYS.png)  

- Dartboard  
	- Usable dartboard for passing time.  
	- Darts are included and be returned if lost.  
![Dartboard](https://i.imgur.com/Gs7iiu5.png) 

## Enemies
- Boomba  
	- A cute little robot.  
![Boomba](https://i.imgur.com/HbKHfJU.png)
	
## Map Hazards
- Teleporter Trap  
	- Teleports you to a random place in the facility when you step on it.  
![TeleporterTrap](https://i.imgur.com/BWPRBwW.png)

## Miscelaneous
- Improved Item Charger.  
	- Stuffing conductive items in the charger will now electrocute you.  
